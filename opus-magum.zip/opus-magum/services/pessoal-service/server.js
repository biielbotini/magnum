
const express = require('express');
const cors = require('cors');
const db = require('./db');

const app = express();

app.use(cors());
app.use(express.json());

const PORT = 3002;

// Consultar funcionários
app.get('/funcionarios', async (req, res) => {
    try {
        const [funcionarios] = await db.query(
            'SELECT * FROM funcionarios ORDER BY nome'
        );

        res.json(funcionarios);

    } catch (erro) {
        res.status(500).json({
            mensagem: 'Erro ao consultar funcionários.'
        });
    }
});

// Cadastrar funcionário
app.post('/funcionarios', async (req, res) => {
    try {
        const {
            nome,
            cpf,
            telefone,
            email,
            cargo,
            salario,
            data_admissao
        } = req.body;

        if (!nome || !cargo || salario === undefined) {
            return res.status(400).json({
                mensagem: 'Preencha nome, cargo e salário.'
            });
        }

        await db.execute(
            `INSERT INTO funcionarios
            (nome, cpf, telefone, email, cargo, salario, data_admissao)
            VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [
                nome,
                cpf || null,
                telefone || null,
                email || null,
                cargo,
                salario,
                data_admissao || null
            ]
        );

        res.status(201).json({
            mensagem: 'Funcionário cadastrado com sucesso!'
        });

    } catch (erro) {
        res.status(500).json({
            mensagem: 'Erro ao cadastrar funcionário.',
            erro: erro.code
        });
    }
});

app.listen(PORT, () => {
    console.log(`Pessoal Service rodando na porta ${PORT}`);
});
