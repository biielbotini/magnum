
async function testar() {
    try {
        // Cadastrar funcionário
        const cadastro = await fetch('http://localhost:3002/funcionarios', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                nome: 'João Silva',
                cpf: '123.456.789-00',
                telefone: '19999999999',
                email: 'joao@opusmagnum.com',
                cargo: 'Auxiliar Administrativo',
                salario: 2500,
                data_admissao: '2026-11-16'
            })
        });

        console.log('Cadastro:', await cadastro.json());

        // Consultar funcionários
        const consulta = await fetch('http://localhost:3002/funcionarios');

        console.log('Funcionários cadastrados:');
        console.log(await consulta.json());

    } catch (erro) {
        console.log('Erro:', erro.message);
    }
}

testar();
