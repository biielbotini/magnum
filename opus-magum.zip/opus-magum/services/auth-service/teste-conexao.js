
const db = require('./db');

async function testar() {
    try {
        const [resultado] = await db.query('SELECT 1');

        console.log('Conexão com MySQL funcionando!');
        console.log(resultado);

    } catch (erro) {
        console.log('Erro na conexão:');
        console.error(erro);

    } finally {
        await db.end();
    }
}

testar();
