
const express = require('express');
const bcrypt = require('bcrypt');
const cors = require('cors');
const db = require('./db');

const app = express();

app.use(cors());
app.use(express.json());

const PORT = 3001;

// Cadastro
app.post('/cadastro', async (req, res) => {
    try {
        const { nome, email, senha, departamento } = req.body;

        if (!nome || !email || !senha || !departamento) {
            return res.status(400).json({
                mensagem: 'Preencha todos os campos.'
            });
        }

        const senhaCriptografada = await bcrypt.hash(senha, 10);

        await db.execute(
            'INSERT INTO usuarios (nome, email, senha, departamento) VALUES (?, ?, ?, ?)',
            [nome, email, senhaCriptografada, departamento]
        );

        res.status(201).json({ mensagem: 'Usuário cadastrado!' });

    } catch (erro) {
        res.status(500).json({ mensagem: 'Erro ao cadastrar usuário.' });
    }
});

// Login
app.post('/login', async (req, res) => {
    try {
        const { email, senha } = req.body;

        const [usuarios] = await db.execute(
            'SELECT * FROM usuarios WHERE email = ?',
            [email]
        );

        if (usuarios.length === 0) {
            return res.status(401).json({ mensagem: 'Email ou senha incorretos.' });
        }

        const usuario = usuarios[0];

        const senhaCorreta = await bcrypt.compare(senha, usuario.senha);

        if (!senhaCorreta) {
            return res.status(401).json({ mensagem: 'Email ou senha incorretos.' });
        }

        res.json({
            mensagem: 'Login realizado!',
            usuario: {
                id: usuario.id,
                nome: usuario.nome,
                email: usuario.email,
                departamento: usuario.departamento
            }
        });

    } catch (erro) {
        res.status(500).json({ mensagem: 'Erro ao fazer login.' });
    }
});

app.listen(PORT, () => {
    console.log(`Auth Service rodando na porta ${PORT}`);
});
