
async function testarCadastro() {
    try {
        const resposta = await fetch('http://localhost:3001/cadastro', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                nome: 'Administrador',
                email: 'admin@opusmagnum.com',
                senha: 'opus123',
                departamento: 'Administração'
            })
        });

        const resultado = await resposta.json();
        console.log('Cadastro:', resultado);

    } catch (erro) {
        console.log('Erro:', erro.message);
    }
}

testarCadastro();
