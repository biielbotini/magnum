
const express = require('express');
const cors = require('cors');
const db = require('./db');

const app = express();

app.use(cors());
app.use(express.json());

const PORT = 3003;

// Consultar movimentações
app.get('/movimentacoes', async (req, res) => {
    try {
        const [movimentacoes] = await db.query(
            'SELECT * FROM movimentacoes ORDER BY data_movimentacao DESC'
        );

        res.json(movimentacoes);

    } catch (erro) {
        res.status(500).json({
            mensagem: 'Erro ao consultar movimentações.'
        });
    }
});

// Registrar receita ou despesa
app.post('/movimentacoes', async (req, res) => {
    try {
        const { tipo, descricao, valor, data_movimentacao } = req.body;

        if (!tipo || !descricao || !valor || !data_movimentacao) {
            return res.status(400).json({
                mensagem: 'Preencha todos os campos.'
            });
        }

        if (!['Receita', 'Despesa'].includes(tipo)) {
            return res.status(400).json({
                mensagem: 'Tipo de movimentação inválido.'
            });
        }

        if (!Number.isFinite(Number(valor)) || Number(valor) <= 0) {
            return res.status(400).json({
                mensagem: 'Informe um valor válido.'
            });
        }

        await db.execute(
            `INSERT INTO movimentacoes
            (tipo, descricao, valor, data_movimentacao)
            VALUES (?, ?, ?, ?)`,
            [tipo, descricao, valor, data_movimentacao]
        );

        res.status(201).json({
            mensagem: 'Movimentação registrada com sucesso!'
        });

    } catch (erro) {
        res.status(500).json({
            mensagem: 'Erro ao registrar movimentação.'
        });
    }
});

// Resumo financeiro
app.get('/resumo', async (req, res) => {
    try {
        const [resultado] = await db.query(`
            SELECT
                SUM(CASE WHEN tipo = 'Receita' THEN valor ELSE 0 END) AS receitas,
                SUM(CASE WHEN tipo = 'Despesa' THEN valor ELSE 0 END) AS despesas
            FROM movimentacoes
        `);

        const receitas = Number(resultado[0].receitas || 0);
        const despesas = Number(resultado[0].despesas || 0);

        res.json({
            receitas,
            despesas,
            saldo: receitas - despesas
        });

    } catch (erro) {
        res.status(500).json({
            mensagem: 'Erro ao calcular resumo financeiro.'
        });
    }
});

app.listen(PORT, () => {
    console.log(`Financeiro Service rodando na porta ${PORT}`);
});
