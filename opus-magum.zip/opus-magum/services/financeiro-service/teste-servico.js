
async function testar() {
    try {
        const resposta = await fetch(
            'http://localhost:3003/movimentacoes',
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    tipo: 'Receita',
                    descricao: 'Venda de produtos químicos',
                    valor: 5000,
                    data_movimentacao: '2026-11-16'
                })
            }
        );

        console.log('Cadastro:', await resposta.json());

        const resumo = await fetch('http://localhost:3003/resumo');

        console.log('Resumo financeiro:', await resumo.json());

    } catch (erro) {
        console.log('Erro:', erro.message);
    }
}

testar();
