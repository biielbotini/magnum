
const express = require('express');
const cors = require('cors');
const db = require('./db');

const app = express();

app.use(cors());
app.use(express.json());

const PORT = 3004;

// Listar produtos
app.get('/produtos', async (req, res) => {
    try {
        const [produtos] = await db.query(
            'SELECT * FROM produtos ORDER BY nome'
        );

        res.json(produtos);
    } catch (erro) {
        console.log(erro);
        res.status(500).json({
            mensagem: 'Erro ao consultar produtos.'
        });
    }
});

// Cadastrar produtos
app.post('/produtos', async (req, res) => {
    try {
        const {
            nome,
            descricao,
            categoria,
            preco,
            quantidade_estoque
        } = req.body;

        if (!nome) {
            return res.status(400).json({
                mensagem: 'O nome do produto é obrigatório.'
            });
        }

        const valor = Number(preco ?? 0);
        const quantidade = Number(quantidade_estoque ?? 0);

        if (!Number.isFinite(valor) || valor < 0 ||
            !Number.isInteger(quantidade) || quantidade < 0) {
            return res.status(400).json({
                mensagem: 'Preço ou quantidade inválidos.'
            });
        }

        await db.execute(
            `INSERT INTO produtos
            (nome, descricao, categoria, preco, quantidade_estoque)
            VALUES (?, ?, ?, ?, ?)`,
            [
                nome,
                descricao || null,
                categoria || null,
                valor,
                quantidade
            ]
        );

        res.status(201).json({
            mensagem: 'Produto cadastrado com sucesso!'
        });

    } catch (erro) {
        console.log(erro);
        res.status(500).json({
            mensagem: 'Erro ao cadastrar produto.'
        });
    }
});

app.listen(PORT, () => {
    console.log(`Producao Service rodando na porta ${PORT}`);
});
