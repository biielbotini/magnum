
async function testar() {
    try {
        const resposta = await fetch('http://localhost:3004/produtos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                nome: 'Desinfetante Opus',
                descricao: 'Desinfetante para limpeza geral',
                categoria: 'Limpeza',
                preco: 15.90,
                quantidade_estoque: 500
            })
        });

        console.log('Cadastro:', await resposta.json());

        const consulta = await fetch('http://localhost:3004/produtos');

        console.log('Produtos cadastrados:', await consulta.json());

    } catch (erro) {
        console.log('Erro:', erro);
    }
}

testar();
