
const usuario = JSON.parse(localStorage.getItem('usuario'));

if (!usuario) {
    window.location.href = 'index.html';
}

const formulario = document.getElementById('formFuncionario');
const mensagem = document.getElementById('mensagem');
const lista = document.getElementById('listaFuncionarios');

function sair() {
    localStorage.removeItem('usuario');
    window.location.href = 'index.html';
}

// Carregar funcionários
async function carregarFuncionarios() {
    try {
        const resposta = await fetch('http://localhost:3002/funcionarios');
        const funcionarios = await resposta.json();

        lista.replaceChildren();

        funcionarios.forEach(funcionario => {
            const linha = document.createElement('tr');

            const dados = [
                funcionario.nome,
                funcionario.cargo,
                funcionario.telefone || '-',
                Number(funcionario.salario).toLocaleString('pt-BR', {
                    style: 'currency',
                    currency: 'BRL'
                })
            ];

            dados.forEach(valor => {
                const celula = document.createElement('td');
                celula.textContent = valor;
                linha.appendChild(celula);
            });

            lista.appendChild(linha);
        });

    } catch (erro) {
        mensagem.textContent = 'Não foi possível carregar os funcionários.';
    }
}

// Cadastrar funcionário
formulario.addEventListener('submit', async (evento) => {
    evento.preventDefault();

    const funcionario = {
        nome: document.getElementById('nome').value,
        cpf: document.getElementById('cpf').value,
        telefone: document.getElementById('telefone').value,
        email: document.getElementById('email').value,
        cargo: document.getElementById('cargo').value,
        salario: Number(document.getElementById('salario').value),
        data_admissao: document.getElementById('data_admissao').value
    };

    try {
        const resposta = await fetch('http://localhost:3002/funcionarios', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(funcionario)
        });

        const resultado = await resposta.json();

        mensagem.textContent = resultado.mensagem;

        if (resposta.ok) {
            formulario.reset();
            carregarFuncionarios();
        }

    } catch (erro) {
        mensagem.textContent = 'Erro ao conectar com o servidor.';
    }
});

carregarFuncionarios();
