
const formulario = document.getElementById('loginForm');

formulario.addEventListener('submit', async (evento) => {
    evento.preventDefault();

    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;
    const mensagem = document.getElementById('mensagem');

    try {
        const resposta = await fetch('http://localhost:3001/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, senha })
        });

        const dados = await resposta.json();

        if (!resposta.ok) {
            mensagem.textContent = dados.mensagem;
            mensagem.style.color = 'red';
            return;
        }

        localStorage.setItem('usuario', JSON.stringify(dados.usuario));

        window.location.href = 'dashboard.html';

    } catch (erro) {
        mensagem.textContent = 'Não foi possível conectar ao servidor.';
        mensagem.style.color = 'red';
    }
});
