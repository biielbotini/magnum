
const API = 'http://localhost:3004';

// Carregar produtos
async function carregarProdutos() {
    try {
        const resposta = await fetch(`${API}/produtos`);
        const produtos = await resposta.json();

        const lista = document.getElementById('listaProdutos');
        lista.innerHTML = '';

        produtos.forEach(produto => {
            lista.innerHTML += `
                <tr>
                    <td>${produto.nome}</td>
                    <td>${produto.categoria || '-'}</td>
                    <td>R$ ${Number(produto.preco || 0).toFixed(2)}</td>
                    <td>${produto.quantidade_estoque}</td>
                </tr>
            `;
        });

    } catch (erro) {
        console.error('Erro ao carregar produtos:', erro);
    }
}

// Cadastrar produto
document.getElementById('formProduto').addEventListener('submit', async (evento) => {
    evento.preventDefault();

    const produto = {
        nome: document.getElementById('nome').value,
        descricao: document.getElementById('descricao').value,
        categoria: document.getElementById('categoria').value,
        preco: Number(document.getElementById('preco').value),
        quantidade_estoque: Number(document.getElementById('quantidade_estoque').value)
    };

    try {
        const resposta = await fetch(`${API}/produtos`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(produto)
        });

        const resultado = await resposta.json();

        if (!resposta.ok) {
            alert(resultado.mensagem || 'Erro ao cadastrar produto.');
            return;
        }

        alert('Produto cadastrado com sucesso!');
        document.getElementById('formProduto').reset();

        carregarProdutos();

    } catch (erro) {
        alert('Não foi possível conectar ao serviço de Produção.');
        console.error(erro);
    }
});

carregarProdutos();
