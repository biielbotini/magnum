
const usuario = JSON.parse(localStorage.getItem('usuario'));

if (!usuario) {
    window.location.href = 'index.html';
}

const formulario = document.getElementById('formFinanceiro');
const mensagem = document.getElementById('mensagem');
const lista = document.getElementById('listaMovimentacoes');

function sair() {
    localStorage.removeItem('usuario');
    window.location.href = 'index.html';
}

function formatarMoeda(valor) {
    return Number(valor).toLocaleString('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    });
}

// Carregar resumo financeiro
async function carregarResumo() {
    try {
        const resposta = await fetch('http://localhost:3003/resumo');
        const dados = await resposta.json();

        document.getElementById('totalReceitas').textContent =
            formatarMoeda(dados.receitas);

        document.getElementById('totalDespesas').textContent =
            formatarMoeda(dados.despesas);

        document.getElementById('saldoAtual').textContent =
            formatarMoeda(dados.saldo);

    } catch (erro) {
        mensagem.textContent = 'Erro ao carregar o resumo financeiro.';
    }
}

// Carregar histórico
async function carregarMovimentacoes() {
    try {
        const resposta = await fetch('http://localhost:3003/movimentacoes');
        const movimentacoes = await resposta.json();

        lista.replaceChildren();

        movimentacoes.forEach(item => {
            const linha = document.createElement('tr');

            const valores = [
                item.tipo,
                item.descricao,
                formatarMoeda(item.valor),
                new Date(item.data_movimentacao).toLocaleDateString('pt-BR')
            ];

            valores.forEach(valor => {
                const celula = document.createElement('td');
                celula.textContent = valor;
                linha.appendChild(celula);
            });

            lista.appendChild(linha);
        });

    } catch (erro) {
        mensagem.textContent = 'Erro ao carregar movimentações.';
    }
}

// Registrar movimentação
formulario.addEventListener('submit', async (evento) => {
    evento.preventDefault();

    const movimentacao = {
        tipo: document.getElementById('tipo').value,
        descricao: document.getElementById('descricao').value,
        valor: Number(document.getElementById('valor').value),
        data_movimentacao: document.getElementById('data_movimentacao').value
    };

    try {
        const resposta = await fetch('http://localhost:3003/movimentacoes', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(movimentacao)
        });

        const dados = await resposta.json();

        mensagem.textContent = dados.mensagem;

        if (resposta.ok) {
            formulario.reset();
            carregarResumo();
            carregarMovimentacoes();
        }

    } catch (erro) {
        mensagem.textContent = 'Não foi possível conectar ao Financeiro.';
    }
});

carregarResumo();
carregarMovimentacoes();
