
CREATE DATABASE IF NOT EXISTS opus_magnum;
USE opus_magnum;

-- USUÁRIOS DO SISTEMA
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    departamento VARCHAR(50) NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- DEPARTAMENTO PESSOAL
CREATE TABLE funcionarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cpf VARCHAR(14) UNIQUE,
    telefone VARCHAR(20),
    email VARCHAR(100),
    cargo VARCHAR(100),
    salario DECIMAL(10,2),
    data_admissao DATE,
    status VARCHAR(20) DEFAULT 'Ativo'
);

-- FINANCEIRO
CREATE TABLE movimentacoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo ENUM('Receita','Despesa') NOT NULL,
    descricao VARCHAR(255) NOT NULL,
    valor DECIMAL(10,2) NOT NULL,
    data_movimentacao DATE NOT NULL
);

-- PRODUÇÃO: PRODUTOS
CREATE TABLE produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT,
    categoria VARCHAR(100),
    preco DECIMAL(10,2),
    quantidade_estoque INT DEFAULT 0
);

-- PRODUÇÃO: MÁQUINAS
CREATE TABLE maquinas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    codigo VARCHAR(50),
    status VARCHAR(30) DEFAULT 'Disponível'
);

-- PRODUÇÃO: TURNOS
CREATE TABLE turnos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL,
    horario_inicio TIME,
    horario_fim TIME
);

-- MARKETING
CREATE TABLE campanhas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    produto VARCHAR(100),
    descricao TEXT,
    data_inicio DATE,
    data_fim DATE,
    status VARCHAR(30) DEFAULT 'Planejada'
);
